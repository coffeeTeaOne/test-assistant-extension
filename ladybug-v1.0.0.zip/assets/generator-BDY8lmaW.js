var R=Object.defineProperty;var C=(t,e,r)=>e in t?R(t,e,{enumerable:!0,configurable:!0,writable:!0,value:r}):t[e]=r;var d=(t,e,r)=>C(t,typeof e!="symbol"?e+"":e,r);import{g as A}from"./utils-DxYl7sTX.js";const h="ai_config",f="export_config",u="login_profiles",m={autoOverwrite:!0};async function D(){try{return(await chrome.storage.local.get(h))[h]||null}catch(t){return console.error("Failed to get AI config:",t),null}}async function P(t){try{await chrome.storage.local.set({[h]:t})}catch(e){throw console.error("Failed to save AI config:",e),e}}async function T(){try{return(await chrome.storage.local.get(f))[f]||{...m}}catch(t){return console.error("Failed to get export config:",t),{...m}}}async function x(t){try{await chrome.storage.local.set({[f]:t})}catch(e){throw console.error("Failed to save export config:",e),e}}async function $(){try{return(await chrome.storage.local.get(u))[u]||[]}catch(t){return console.error("Failed to get login profiles:",t),[]}}async function N(t){try{const e=await $(),r=e.findIndex(a=>a.id===t.id);r>=0?e[r]=t:e.push(t),await chrome.storage.local.set({[u]:e})}catch(e){throw console.error("Failed to save login profile:",e),e}}async function G(t){try{const r=(await $()).filter(a=>a.id!==t);await chrome.storage.local.set({[u]:r})}catch(e){throw console.error("Failed to delete login profile:",e),e}}const g="recordings",y="current_recording";async function v(){try{return(await chrome.storage.local.get(g))[g]||[]}catch(t){return console.error("Failed to get recordings:",t),[]}}async function F(t){try{const e=await v(),r=e.findIndex(a=>a.id===t.id);r>=0?e[r]=t:e.push(t),await chrome.storage.local.set({[g]:e})}catch(e){throw console.error("Failed to save recording:",e),e}}async function L(t){try{const r=(await v()).filter(a=>a.id!==t);await chrome.storage.local.set({[g]:r})}catch(e){throw console.error("Failed to delete recording:",e),e}}async function p(t){try{t?await chrome.storage.local.set({[y]:t}):await chrome.storage.local.remove(y)}catch(e){throw console.error("Failed to set current recording:",e),e}}async function _(t,e){try{await chrome.tabs.sendMessage(t,e)}catch(r){throw console.warn(`Failed to send message to tab ${t}:`,r),r}}async function S(){try{const[t]=await chrome.tabs.query({active:!0,currentWindow:!0});return t||null}catch(t){return console.warn("Failed to get active tab:",t),null}}async function I(t){try{await chrome.runtime.sendMessage(t)}catch(e){throw console.warn("Failed to send runtime message:",e),e}}async function K(){try{await chrome.sidePanel.open()}catch(t){throw console.warn("Failed to open side panel:",t),t}}class Y{constructor(){d(this,"isRecording",!1);d(this,"currentSession",null)}async startRecording(){this.isRecording=!0;let e="zh";try{const n=await chrome.storage.local.get("app_language");(n.app_language==="zh"||n.app_language==="en")&&(e=n.app_language)}catch{}const r=e==="en"?"Recording":"录制",a=e==="en"?"en-US":"zh-CN",o={id:A(),name:`${r}_${new Date().toLocaleString(a)}`,createdAt:Date.now(),updatedAt:Date.now(),steps:[]};this.currentSession=o,await p(o);try{const n=await S();n!=null&&n.id&&await _(n.id,{type:"START_RECORDING"})}catch(n){console.warn("Failed to notify content script of recording start:",n)}return o}async stopRecording(){this.isRecording=!1;try{const e=await S();e!=null&&e.id&&await _(e.id,{type:"STOP_RECORDING"})}catch(e){console.warn("Failed to notify content script of recording stop:",e)}if(this.currentSession){await F(this.currentSession);const e=this.currentSession;return this.currentSession=null,await p(null),e}return null}async addStep(e){return!e||!e.id||!e.action||!e.target||!e.target.selector?(console.warn("Skipping invalid step: missing required fields",e),!1):!this.currentSession||!this.isRecording?!1:(this.currentSession.steps.push(e),this.currentSession.updatedAt=Date.now(),await p(this.currentSession),await this.notifySidePanel({type:"RECORDING_UPDATED",payload:{isRecording:this.isRecording,steps:this.currentSession.steps}}),!0)}isCurrentlyRecording(){return this.isRecording}getCurrentSteps(){var e;return((e=this.currentSession)==null?void 0:e.steps)||[]}async notifySidePanel(e){try{await I(e)}catch(r){console.warn("Failed to notify side panel:",r)}}}function s(t){return t.replace(/\\/g,"\\\\").replace(/"/g,'\\"').replace(/\n/g,"\\n")}function b(t,e){var o;const r=e==="headless",a=t.steps.map((n,i)=>{var w;const c=n.target,l=c.xpath?`page.locator("xpath=${s(c.xpath)}")`:`page.locator("${s(c.selector||"body")}")`;switch(n.action){case"click":return`    # Step ${i+1}: click
    ${l}.wait_for(state="visible", timeout=10000)
    ${l}.click()
    page.wait_for_load_state("networkidle")`;case"input":return`    # Step ${i+1}: input
    ${l}.fill("${s(n.value||"")}")
    ${l}.dispatch_event("input")
    ${l}.dispatch_event("change")`;case"select":return`    # Step ${i+1}: select
    ${l}.check()`;case"navigate":return`    # Step ${i+1}: navigate
    page.goto("${s(n.url||((w=t.steps[0])==null?void 0:w.url)||"")}")
    page.wait_for_load_state("networkidle")`;case"wait":return`    # Step ${i+1}: wait
    page.wait_for_timeout(${parseInt(n.value||"1000")})`;default:return`    # Step ${i+1}: ${n.action} (unsupported)`}}).join(`

`);return`"""
Auto-generated Playwright test script
Test case: ${s(t.name)}
Steps: ${t.steps.length}
Generated at: ${new Date().toISOString()}
"""

from playwright.sync_api import sync_playwright


def run_test():
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=${r})
        context = browser.new_context(
            viewport={"width": 1920, "height": 1080},
            ignore_https_errors=True
        )
        page = context.new_page()

        # Navigate to starting page
        page.goto("${s(((o=t.steps[0])==null?void 0:o.url)||"about:blank")}")
        page.wait_for_load_state("networkidle")

${a}

        print("All steps completed successfully.")
        context.close()
        browser.close()


if __name__ == "__main__":
    run_test()
`}function E(t){var r;const e=t.steps.map((a,o)=>{var c;const n=a.target,i=n.xpath?`(By.XPATH, "${s(n.xpath)}")`:`(By.CSS_SELECTOR, "${s(n.selector||"body")}")`;switch(a.action){case"click":return`    # Step ${o+1}: click
    driver.find_element${i}.click()
    time.sleep(1)`;case"input":return`    # Step ${o+1}: input
    element = driver.find_element${i}
    element.clear()
    element.send_keys("${s(a.value||"")}")`;case"select":return`    # Step ${o+1}: select
    element = driver.find_element${i}
    if not element.is_selected():
        element.click()`;case"navigate":return`    # Step ${o+1}: navigate
    driver.get("${s(a.url||((c=t.steps[0])==null?void 0:c.url)||"")}")`;case"wait":return`    # Step ${o+1}: wait
    time.sleep(${parseInt(a.value||"1000")/1e3})`;default:return`    # Step ${o+1}: ${a.action} (unsupported)`}}).join(`

`);return`"""
Auto-generated Selenium test script
Test case: ${s(t.name)}
Steps: ${t.steps.length}
Generated at: ${new Date().toISOString()}
"""

from selenium import webdriver
from selenium.webdriver.common.by import By
import time


def run_test():
    driver = webdriver.Chrome()
    driver.implicitly_wait(10)

    try:
        driver.get("${s(((r=t.steps[0])==null?void 0:r.url)||"about:blank")}")

${e}

        print("All steps completed successfully.")

    finally:
        driver.quit()


if __name__ == "__main__":
    run_test()
`}async function M(t,e,r){const a=(r==null?void 0:r.mode)||"gui";if(e==="playwright"){const o=b(t,a);return{language:"python",framework:"playwright",mode:a,code:o,generatedAt:Date.now()}}else return{language:"python",framework:"selenium",mode:"gui",code:E(t),generatedAt:Date.now()}}function U(t){const e={id:t.id,name:t.name,createdAt:t.createdAt,updatedAt:t.updatedAt,steps:t.steps.map((r,a)=>({stepIndex:a+1,action:r.action,target:r.target,value:r.value,url:r.url,timestamp:r.timestamp}))};return JSON.stringify(e,null,2)}export{Y as R,L as a,M as b,D as c,G as d,T as e,$ as f,U as g,v as h,x as i,N as j,F as k,K as o,P as s};
