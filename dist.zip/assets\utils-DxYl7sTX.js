function t(){return`${Date.now()}-${Math.random().toString(36).substring(2,11)}`}export{t as g};
