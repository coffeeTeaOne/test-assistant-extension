Icon placeholder
